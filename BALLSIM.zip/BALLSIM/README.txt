BALL SIMULATION v1.0 by kelograph

This program is a ball simulation for the TI-84 plus CE, and it includes gravity and speed variables which can be changed.
Since this program is written in TI-BASIC, it doesnt need a shell to run on TI-OS v5.3 or higher!
If you are using a shell, the hex code at line 2 will show a icon :)

This code is open source, feel free to use it!

DOWNLOAD INSTRUCTIONS:
1) unzip BALLSIM.zip

2) Put BALL.8xp on your calculator using TI Connect CE
 
3) run the program on your calculator!
